package com.rentalcar.repository;

import com.rentalcar.entity.VehicleRegistrationDoc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleRegistrationDocRepository extends JpaRepository<VehicleRegistrationDoc, Long> {}
