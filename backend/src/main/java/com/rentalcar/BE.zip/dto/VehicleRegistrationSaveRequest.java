package com.rentalcar.dto;

public class VehicleRegistrationSaveRequest {
    public String plate;
    public String owner;
    public String frameNo;
    public String engineNo;
    public String rawJson;
}
